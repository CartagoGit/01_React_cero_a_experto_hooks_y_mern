
export const heroImages = require.context('../assets/heroes', true );