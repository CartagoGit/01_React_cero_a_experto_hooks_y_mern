

export const types = {
    login : '[auth] Login',
    logout: '[auth] Logout',
}